package com.app.pojos;

public enum Status {
	ACTIVE,INACTIVE
	//Active to be shown in customer list
}
