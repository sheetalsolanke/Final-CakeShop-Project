package com.app.pojos;

public enum PaymentStatus {
	PENDING,COMPLETED,REFUNDED
}
