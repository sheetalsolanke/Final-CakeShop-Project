package com.app.pojos;

public enum Type {
	COD,CARD,UPI,NETBANKING
}
